import './App.css';
import nur from './products.json';
import 'bootstrap/dist/css/bootstrap.css';
import { useState, useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import categoriesData from './categories';
import axios from 'axios';

function App() {
  const [data, setData] = useState(null);
  const [app, setApp] = useState(nur);
  const [categories, setCategories] = useState(categoriesData);
  const [initialApp, setInitialApp] = useState(nur);
  const [filters, setFilters] = useState({ searchText: '' });
  const [usdExchangeRate, setUsdExchangeRate] = useState(null);

  useEffect(() => {
    axios.get('https://api.exchangerate-api.com/v4/latest/USD')
      .then(response => {
        setUsdExchangeRate(response.data.rates.EUR);
      })
      .catch(error => {
        console.error('Ошибка загрузки курса валют:', error);
      });
  }, []);

  const handleFilterChange = (e) => {
    const { value } = e.target;
    setFilters({ searchText: value });

    const searchText = value.toLowerCase();
    const filteredProducts = initialApp.filter((product) => {
      return product.title.toLowerCase().includes(searchText);
    });
    setApp(filteredProducts);
  };

  return (
    <>
      <Navbar style={{ position: 'fixed' }} variant='light' expand="lg" className="custom-navbar">
        <Container fluid>
          <Navbar.Brand href="#">MAIN</Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
            {/* <audio src='music.mp3'controls/> */}
            <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: '100px' }}
              navbarScroll
            >
              <NavDropdown title="Категории" id="navbarScrollingDropdown">
                <NavDropdown.Item href="#action3">discount</NavDropdown.Item>
                {categories.map((category) => (
                  <div key={category.id}>
                    <NavDropdown.Divider />
                    <NavDropdown.Item>{category.title}</NavDropdown.Item>
                  </div>
                ))}
                <NavDropdown.Item href="#action5">home</NavDropdown.Item>
              </NavDropdown>
            </Nav>
            <Form className="d-flex">
              <Form.Control
                type="search"
                placeholder="Search"
                className="me-2"
                aria-label="Search"
                name="searchText"
                value={filters.searchText}
                onChange={handleFilterChange}
              />
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <div className='bos_adapte'>
        {app.map((mp, index) => (
          <div className='ramka' key={index}>
            {mp.discount !== null ? <div className='ramka__discount'>
              <div className='discount__ds'>{mp.discount}%</div>
            </div> : null}
              <div style={{backgroundImage:`url(${mp.main_image.path.original})`}} className='ramka__img'></div>
            <p className='ramka__text_name'>{mp.title}</p>
            <button className='ramka__button'>
              {mp.discount != null ? <div className='adp'><p> {mp.price - mp.price / 100 * mp.discount}$</p><s className='disc'>{mp.price}</s></div> : <div>{mp.price}</div>}
            </button>
            <div className='ramka__adapte'>
              <div className='adapte__icons' ></div>
              <div className='adapte__icons adapte__icons_3' ></div>
              <div className='adapte__icon_2 adapte__icons' >
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

export default App;
